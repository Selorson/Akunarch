---
name: metro-route-3d-video
description: Tạo video dọc 9:16 (1080x1920) mô phỏng tuyến metro 3D nghiêng trên nền ảnh vệ tinh Esri từ file KML — tàu 5 toa chạy 2 chiều, đoạn ngầm tô sáng, đoạn trên cao có cầu 1 trụ giữa, ray vẽ dần sau tàu. Dùng khi người dùng gửi KML/tên tuyến metro và muốn xem/xuất animation tàu chạy.
---

# Video tuyến metro 3D trên ảnh vệ tinh

Render trong khung trình duyệt của app Claude desktop (canvas 2D + WebCodecs VP8 -> WebM). Nền: Esri World_Imagery (tile cùng origin `/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}`).
Sandbox shell KHÔNG tới được server tile -> chỉ render được trong khung trình duyệt. Khung phải ở trạng thái `visible`.

## Quy tắc bắt buộc
1. **Cầu có sẵn**: toàn bộ cầu cạn + trụ hiện đủ từ khung hình đầu. KHÔNG quay animation xây cầu (tuỳ chọn `bridge`/`pierLead`/`noB` chỉ dùng khi người dùng yêu cầu rõ). Chỉ ray đỏ được vẽ dần SAU tàu. Animation = tàu A từ ga đầu tới ga cuối, tàu B ngược lại.
2. **Cầu cạn chỉ MỘT trụ ở giữa** (chữ T: trụ + xà ngang). Không làm 2 trụ.
3. **Cửa hầm**: nhãn "CỬA HẦM" (cyan, glow) + vòng mảnh tại điểm chuyển ngầm -> cao.
4. **Đoạn ngầm tô sáng**: hành lang cyan sáng phủ toàn đoạn ngầm (rộng ~32 px thế giới) + 2 viền sáng; tàu trong hầm ánh cyan, mờ, có glow. Ray ngầm đỏ đậm (#c4231f) nét đứt, vẽ dần sau tàu. Đoạn trên cao: dải cầu xám trắng, ray đỏ (#e8403a).
5. **Tàu 5 toa**, mỗi toa quay theo dây cung -> uốn mượt qua khúc cua. Tuyến mượt: Catmull-Rom hướng tâm -> lấy mẫu 2 px -> trung bình trượt (w=22, 3 lượt).
6. **Bóng cầu vẽ từng đoạn ngắn** (độ dày theo khoảng cách). Vẽ 1 nét dài sẽ ra mảng xám khổng lồ.
7. **Chữ luôn nằm trong khung**: lề 2 bên >= 64 px; nhãn ga kẹp trong lề, ẩn nếu rơi vào vùng tiêu đề/chú giải (y<250) hoặc sát đáy; tiêu đề tự co chữ vừa khung. Chú giải vẽ bằng nét (không dùng ký tự ┄ ━ vì thiếu glyph).
8. **Camera không bao giờ đứng yên**: xoay yaw ±38°, nghiêng 30–34°, cuối kéo lùi toàn cảnh (D 270->430, alpha->40, ahead -70->+130). Không CTA.
9. Header: "● CHỦ ĐỀ" trái, "Đình Văn Discover" phải. Dòng nguồn nhỏ dưới đáy.
10. Trước khi xuất video đầy đủ: dựng 3 ảnh tĩnh (ga đầu, đoạn ngầm gần cửa hầm, đoạn trên cao) cho người dùng duyệt nếu họ chưa xem mô hình.

## Quy trình
1. Nhận KML (`<coordinates>` lon,lat,0 ...) + danh sách ga (tên, lat, lon) + chỉ số cửa hầm. Ga/cửa hầm chỉ gần đúng -> nói rõ với người dùng. Mẫu: `scripts/stations_example.json`.
2. Font: nếu người dùng gửi .otf/.ttf (ví dụ BT Danta Bold), subset bằng `pyftsubset` (TÙY CHỌN MẶC ĐỊNH — bỏ `--layout-features=` rỗng và `--no-hinting`, Chrome từ chối "Invalid font data"), xuất woff2 -> base64 -> dán vào khung trình duyệt theo mảnh 400–2400 ký tự, kiểm checksum từng mảnh (`sum=(x)=>[...x].reduce((a,c,j)=>a+c.charCodeAt(0)*(j%7+1),0)%65521`), rồi `new FontFace(name, bytes, {weight:'700'})`, `document.fonts.add`. Truyền tên font vào `createDraw3D(R,{font:name})`. Bộ ký tự cần gồm toàn bộ chuỗi tiếng Việt trên giao diện.
3. Mở khung: nếu "No browser pane is open" -> `navigate` tới `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/2/1/1` (origin này cho fetch tile cùng-origin). Mọi biến toàn cục mất khi điều hướng.
4. Dán `scripts/route.js` rồi chạy:
   ```js
   const kml = `...nội dung KML...`;
   window.RT = MetroRoute.buildRoute(MetroRoute.parseKML(kml), STATIONS, {reverse:true, portalBetween:[2,.3]});
   ```
   `reverse:true` khi KML chạy từ cuối tuyến về đầu. `RT.len` = chiều dài (px thế giới zoom 16, ~2.35 m/px ở lat 10.8). Tuyến Bến Thành–Suối Tiên: len≈8006, 89 điểm KML.
5. Dán `scripts/metro3d.js`: `window.draw3D = createDraw3D(RT,{font:'TênFont'});` rồi thử 1 khung: `const c = await draw3D(200, 7800, {yaw:-38, alpha:32}); img.src=c.toDataURL('image/jpeg',.85)` để xem trước.
6. Dán `scripts/exporter.js` (sửa N, tên file, dòng thời gian trong `frame(t)`). Chạy async, poll `ST` bằng `await new Promise(r=>setTimeout(()=>r(JSON.stringify(ST)),30000))`. Tốc độ quan sát ~43 khung/s (900 khung ≈ 21 s).
7. Kiểm tra: `ST.vis==='visible'`, `ST.dur`≈ thời lượng, số khung đủ. Báo người dùng bấm nút "TẢI VIDEO" ngay (video chỉ nằm trong khung).

## Tuỳ chọn draw3D(sA,pB,o)
- `sA`: đầu tàu A (chạy tới, 0->len). `pB`: đầu tàu B (chạy ngược). 
- `o.yaw` (độ), `o.alpha` (độ, mặc định 34), `o.D` (270), `o.ahead` (-70, tâm nhìn so với đầu tàu A), `o.cs` (ép tâm nhìn tại vị trí cung).
- Tuỳ chọn hiếm: `o.bridge` (cầu chỉ dựng tới vị trí này), `o.pierLead`, `o.noB` (ẩn tàu B). Mặc định KHÔNG dùng.

## Điểm cần nói với người dùng khi giao
- Ga + cửa hầm gần đúng (KML chỉ có đường tuyến). Nhãn có thể bị ẩn khi lọt vùng tiêu đề.
- 30 s cho cả ~18,8 km -> tàu rất nhanh; muốn thong thả thì kéo dài video.
- Ảnh vệ tinh Esri/Maxar chỉ minh hoạ.
