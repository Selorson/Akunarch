// metro3d.js — vẽ 1 khung 3D nghiêng (canvas 1080x1920) của tuyến metro 2 chiều: ngầm (vùng sáng) + trên cao (cầu 1 trụ giữa).
// Dùng trong khung trình duyệt: const draw3D = createDraw3D(R, {font:'BTDanta B'});
// c = await draw3D(sA, pB, {yaw, alpha, D, ahead, cs})  -> canvas
//   sA: vị trí ĐẦU tàu A (chạy tới, 0 -> len), pB: vị trí đầu tàu B (chạy ngược, len -> 0)
//   alpha: độ nghiêng (độ, mặc định 34), D: khoảng cách camera (270), yaw: xoay quanh tuyến (độ),
//   ahead: tâm nhìn so với đầu tàu A (-70 = lệch sau), cs: ép tâm nhìn tại vị trí cung này.
// QUY TẮC: cầu cạn có SẴN từ khung hình đầu (không quay cảnh xây). Chỉ ray đỏ vẽ dần sau tàu.
function createDraw3D(R,cfg={}){
const W=cfg.W||1080,H=cfg.H||1920,FONT=cfg.font||'sans-serif';
const TITLE=cfg.title||'METRO SỐ 1 · Bến Thành – Suối Tiên',HL=cfg.headerLeft||'CHỦ ĐỀ',HR=cfg.headerRight||'Đình Văn Discover';
const CREDIT=cfg.credit||'Ảnh vệ tinh: Esri, Maxar · Tuyến theo KML, vị trí ga và cửa hầm gần đúng';
const COL='#e8403a',CY='#6fe6ff',DR='#c4231f';
const OFF=6,LC=30,GAP=3,NCARS=5,CW=7,CH=7,HZ=26,RAMP=170;
const ss=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
const hz=q=>q<R.sPortal?0:HZ*ss((q-R.sPortal)/RAMP);
const hdg=q=>{const a=R.pt(q-45),b=R.pt(q+45),dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[dx/l,dy/l]};
const fnt=px=>'700 '+px+'px "'+FONT+'", sans-serif';
return async(sA,pB,o={})=>{
 const alpha=(o.alpha??34)*Math.PI/180,D=o.D??270,FOC=1900,SY0=H*.64,yaw=(o.yaw||0)*Math.PI/180;
 const cs=o.cs??Math.min(sA+(o.ahead??-70),R.len-250),C=R.pt(cs),h0=hdg(cs),f=[h0[0]*Math.cos(yaw)-h0[1]*Math.sin(yaw),h0[0]*Math.sin(yaw)+h0[1]*Math.cos(yaw)],r=[-f[1],f[0]];
 const Ec=[0,-D*Math.cos(alpha),D*Math.sin(alpha)],F=[0,Math.cos(alpha),-Math.sin(alpha)],Uv=[0,Math.sin(alpha),Math.cos(alpha)];
 const proj=(x,y,z)=>{const dx=x-C[0],dy=y-C[1];const u=dx*r[0]+dy*r[1],v=dx*f[0]+dy*f[1];const ry=v-Ec[1],rz=z-Ec[2];const zc=ry*F[1]+rz*F[2],yc=ry*Uv[1]+rz*Uv[2],zz=Math.max(zc,60);return[W/2+FOC*u/zz,SY0-FOC*yc/zz,zc]};
 const eyeW=[C[0]+Ec[0]*r[0]+Ec[1]*f[0],C[1]+Ec[0]*r[1]+Ec[1]*f[1],Ec[2]];
 const c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
 g.fillStyle='#0a1220';g.fillRect(0,0,W,H);
 // --- vùng tile cần tải: chiếu 5 điểm màn hình xuống mặt đất
 let bx0=1e12,bx1=-1e12,by0=1e12,by1=-1e12;
 for(const [sx,sy] of [[0,0],[W,0],[0,H],[W,H],[W/2,0]]){const a=(sx-W/2)/FOC,b=(SY0-sy)/FOC;const dy=b*Uv[1]+F[1],dz=b*Uv[2]+F[2];let t=dz<-.06?-Ec[2]/dz:(-Ec[2]/-.06);t=Math.min(t,1700);const u=Ec[0]+t*a,v=Ec[1]+t*dy;const x=C[0]+u*r[0]+v*f[0],y=C[1]+u*r[1]+v*f[1];bx0=Math.min(bx0,x);bx1=Math.max(bx1,x);by0=Math.min(by0,y);by1=Math.max(by1,y)}
 const jobs=[];for(let ty=Math.floor(by0/256);ty<=Math.floor(by1/256);ty++)for(let tx=Math.floor(bx0/256);tx<=Math.floor(bx1/256);tx++)jobs.push(R.tile(tx,ty).then(b=>({b,tx,ty})));
 const tiles=await Promise.all(jobs);
 // --- nền vệ tinh: mỗi tile chia 8x8 ô, mỗi ô 2 tam giác affine (hiệu ứng phối cảnh)
 const tri=(img,s0,s1,s2,d0,d1,d2)=>{const den=s0[0]*(s1[1]-s2[1])+s1[0]*(s2[1]-s0[1])+s2[0]*(s0[1]-s1[1]);if(!den)return;
  const a=(d0[0]*(s1[1]-s2[1])+d1[0]*(s2[1]-s0[1])+d2[0]*(s0[1]-s1[1]))/den,b=(d0[1]*(s1[1]-s2[1])+d1[1]*(s2[1]-s0[1])+d2[1]*(s0[1]-s1[1]))/den;
  const cc=(d0[0]*(s2[0]-s1[0])+d1[0]*(s0[0]-s2[0])+d2[0]*(s1[0]-s0[0]))/den,d=(d0[1]*(s2[0]-s1[0])+d1[1]*(s0[0]-s2[0])+d2[1]*(s1[0]-s0[0]))/den;
  const e=(d0[0]*(s1[0]*s2[1]-s2[0]*s1[1])+d1[0]*(s2[0]*s0[1]-s0[0]*s2[1])+d2[0]*(s0[0]*s1[1]-s1[0]*s0[1]))/den,ff=(d0[1]*(s1[0]*s2[1]-s2[0]*s1[1])+d1[1]*(s2[0]*s0[1]-s0[0]*s2[1])+d2[1]*(s0[0]*s1[1]-s1[0]*s0[1]))/den;
  const mx=(d0[0]+d1[0]+d2[0])/3,my=(d0[1]+d1[1]+d2[1])/3,k=1.05;
  g.save();g.beginPath();g.moveTo(mx+(d0[0]-mx)*k,my+(d0[1]-my)*k);g.lineTo(mx+(d1[0]-mx)*k,my+(d1[1]-my)*k);g.lineTo(mx+(d2[0]-mx)*k,my+(d2[1]-my)*k);g.closePath();g.clip();g.setTransform(a,b,cc,d,e,ff);g.drawImage(img,0,0);g.restore()};
 const N=8;
 for(const {b,tx,ty} of tiles){if(!b)continue;const iw=b.width/N;const P=[];for(let j=0;j<=N;j++){P[j]=[];for(let i=0;i<=N;i++)P[j][i]=proj(tx*256+i*256/N,ty*256+j*256/N,0)}
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){const p00=P[j][i],p10=P[j][i+1],p01=P[j+1][i],p11=P[j+1][i+1];if(p00[2]<30||p10[2]<30||p01[2]<30||p11[2]<30)continue;
   const mnx=Math.min(p00[0],p10[0],p01[0],p11[0]),mxx=Math.max(p00[0],p10[0],p01[0],p11[0]),mny=Math.min(p00[1],p10[1],p01[1],p11[1]),mxy=Math.max(p00[1],p10[1],p01[1],p11[1]);if(mxx<-50||mnx>W+50||mxy<-50||mny>H+50)continue;
   const s00=[i*iw,j*iw],s10=[(i+1)*iw,j*iw],s01=[i*iw,(j+1)*iw],s11=[(i+1)*iw,(j+1)*iw];tri(b,s00,s10,s01,p00,p10,p01);tri(b,s10,s11,s01,p10,p11,p01)}}
 g.fillStyle='rgba(6,14,28,.25)';g.fillRect(0,0,W,H);
 const fog=g.createLinearGradient(0,0,0,H*.42);fog.addColorStop(0,'rgba(8,16,30,.95)');fog.addColorStop(1,'rgba(8,16,30,0)');g.fillStyle=fog;g.fillRect(0,0,W,H*.42);
 const sc=(zc,w)=>Math.max(.8,FOC*w/Math.max(zc,60));
 const P3=(s,off,dz=0)=>{const p=R.off(s,off);return proj(p[0],p[1],hz(s)+dz)};
 const trk=[[0,sA,OFF],[pB,R.len,-OFF]];            // đoạn ray ĐÃ có tàu đi qua (vẽ dần sau tàu)
 const uni=[[0,o.bridge??R.len]];                    // cầu cạn: có sẵn toàn tuyến (o.bridge chỉ dùng nếu muốn animation xây cầu)
 const line=(s0,s1,off,z,w,col,blur)=>{g.save();if(blur){g.shadowColor=col;g.shadowBlur=blur}g.strokeStyle=col;g.lineCap='round';g.lineJoin='round';
  let prev=null;for(let s=s0;s<=s1+.1;s+=6){const q=P3(Math.min(s,s1),off,z);if(prev){g.lineWidth=sc(q[2],w);g.beginPath();g.moveTo(prev[0],prev[1]);g.lineTo(q[0],q[1]);g.stroke()}prev=q}g.restore()};
 // --- bóng cầu: vẽ từng đoạn ngắn, độ dày theo khoảng cách (đừng vẽ 1 nét dài — sẽ ra mảng xám khổng lồ)
 for(const [a,b] of uni){const s0=Math.max(a,R.sPortal+10);if(b<=s0)continue;let prev=null;g.save();g.lineCap='butt';g.strokeStyle='rgba(0,0,0,.26)';for(let s=s0;s<=b+.1;s+=6){const sq=Math.min(s,b),p=R.off(sq,0),h=hz(sq);const q=proj(p[0]+h*.45,p[1]+h*.8,0);if(prev&&q[2]>60&&prev[2]>60){g.lineWidth=sc(q[2],20);g.beginPath();g.moveTo(prev[0],prev[1]);g.lineTo(q[0],q[1]);g.stroke()}prev=q}g.restore()}
 // --- VÙNG NGẦM: hành lang sáng cyan toàn đoạn ngầm + 2 viền sáng
 {const e=R.sPortal;const rb=w=>{g.beginPath();for(let s=0;s<=e;s+=6){const q=P3(s,-w);s?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])}for(let s=e;s>=0;s-=6){const q=P3(s,w);g.lineTo(q[0],q[1])}g.closePath()};
  g.save();g.shadowColor=CY;g.shadowBlur=55;g.fillStyle='rgba(111,230,255,.30)';rb(16);g.fill();g.shadowBlur=0;g.fillStyle='rgba(150,240,255,.24)';rb(16);g.fill();g.restore();
  line(0,e,-16,0,2.6,'rgba(205,252,255,.95)',26);line(0,e,16,0,2.6,'rgba(205,252,255,.95)',26)}
 // --- ray ngầm (đỏ đậm, nét đứt phát sáng) vẽ dần sau tàu
 for(const [a,b,o2] of trk){const e=Math.min(b,R.sPortal);if(a>=e)continue;line(a,e,o2,0,15,'rgba(0,0,0,.35)');
  for(let s=a;s<e;s+=6){if(Math.floor(s/18)%2===0){line(s,Math.min(s+6,e),o2,0,4.6,DR,26)}}}
 // --- vòng đánh dấu cửa hầm
 {const p=proj(...R.off(R.sPortal,0),0);g.save();g.shadowColor=CY;g.shadowBlur=24;g.strokeStyle=CY;g.lineWidth=sc(p[2],2);g.beginPath();g.ellipse(p[0],p[1],sc(p[2],21),sc(p[2],21)*.5,0,0,7);g.stroke();g.restore()}
 // --- trụ cầu: MỘT trụ giữa + xà ngang (chữ T). o.pierLead>0 chỉ dùng cho animation xây cầu.
 const drawPiers=(a,b)=>{const piers=[];for(let s=Math.max(a,R.sPortal+40);s<=b;s+=60){if(hz(s)<4)continue;const kk=o.bridge==null?1:Math.max(0,Math.min(1,(o.bridge+(o.pierLead||0)-s)/70));const p=R.off(s,0),h=hz(s)*kk;if(h<3)continue;const t=R.tan(s);piers.push({b:proj(p[0],p[1],0),t:proj(p[0],p[1],h-3.5),c1:proj(p[0]+t[1]*8,p[1]-t[0]*8,h-3.5),c2:proj(p[0]-t[1]*8,p[1]+t[0]*8,h-3.5)})}
 piers.sort((x,y)=>y.b[2]-x.b[2]);for(const q of piers){g.strokeStyle='#9aa2ac';g.lineCap='butt';g.lineWidth=sc(q.b[2],7);g.beginPath();g.moveTo(q.b[0],q.b[1]);g.lineTo(q.t[0],q.t[1]);g.stroke();g.strokeStyle='rgba(255,255,255,.28)';g.lineWidth=sc(q.b[2],2);g.beginPath();g.moveTo(q.b[0]-sc(q.b[2],1.8),q.b[1]);g.lineTo(q.t[0]-sc(q.b[2],1.8),q.t[1]);g.stroke();g.strokeStyle='#838b95';g.lineWidth=sc(q.b[2],4.5);g.beginPath();g.moveTo(q.c1[0],q.c1[1]);g.lineTo(q.c2[0],q.c2[1]);g.stroke()}};
 // --- mặt cầu (1 dải chung 2 chiều): thành xa -> trụ -> thành gần -> mặt
 for(const [a,b] of uni){const s0=Math.max(a,R.sPortal);if(b<=s0+8)continue;
  const strip=(zOff1,w1,zOff2,w2,fill)=>{g.beginPath();let first=true;for(let s=s0;s<=b;s+=6){const q=P3(s,w1,zOff1);if(first){g.moveTo(q[0],q[1]);first=false}else g.lineTo(q[0],q[1])}for(let s=b;s>=s0;s-=6){const q=P3(s,w2,zOff2);g.lineTo(q[0],q[1])}g.closePath();g.fillStyle=fill;g.fill()};
  const mid=(s0+b)/2;const nearL=P3(mid,-9)[2]<P3(mid,9)[2];const skL=()=>strip(0,-9,-4,-9,'#8e969f'),skR=()=>strip(0,9,-4,9,'#7a828b');(nearL?skR:skL)();drawPiers(s0,b+(o.pierLead||0));(nearL?skL:skR)();strip(0,-9,0,9,'#e3e7ec');strip(0,-1.2,0,1.2,'#c3c9d0')}
 if(o.bridge!=null&&o.bridge<R.len){const q=P3(o.bridge,0);g.save();g.shadowColor='#ffd24a';g.shadowBlur=40;g.fillStyle='#ffd24a';g.beginPath();g.ellipse(q[0],q[1],sc(q[2],7),sc(q[2],7)*.5,0,0,7);g.fill();g.restore()}
 // --- ray đỏ trên cầu, vẽ dần sau tàu
 for(const [a,b,o2] of trk){const s0=Math.max(a,R.sPortal);if(b<=s0+8)continue;for(const rl of [-2,2])line(s0,b,o2+rl,.3,2.6,COL)}
 // --- ga + nhãn
 const labels=[];R.ST.forEach((s,i)=>{const sp=R.stS[i],p=R.pt(sp),q=proj(p[0],p[1],hz(sp)),u=sp<R.sPortal;if(q[2]<60)return;const rr=sc(q[2],10);g.fillStyle='#fff';g.strokeStyle=u?'#5fc8e6':COL;g.lineWidth=rr*.4;g.beginPath();g.ellipse(q[0],q[1],rr,rr*.55,0,0,7);g.fill();g.stroke();labels.push([s[0],q,u,'st'])});
 labels.push(['CỬA HẦM',proj(...R.off(R.sPortal,0),0),true,'portal']);
 // --- đoàn tàu 5 toa: hộp 3D, mặt khuất bị loại theo pháp tuyến, mỗi toa quay theo dây cung -> uốn theo đường cong
 const light=[.45,-.5,.74];const cars=[];
 const mk=(sh,dir)=>{for(let i=0;i<NCARS;i++){const sc2=sh-dir*((i+.5)*LC+i*GAP);cars.push({sc:sc2,dir,head:i===0,o:dir>0?OFF:-OFF})}};mk(sA,1);if(!o.noB)mk(pB,-1);
 for(const cr of cars){const a=R.off(cr.sc-LC/2,cr.o),b=R.off(cr.sc+LC/2,cr.o),m=R.off(cr.sc,cr.o);let ang=Math.atan2(b[1]-a[1],b[0]-a[0]);if(cr.dir<0)ang+=Math.PI;cr.m=m;cr.ang=ang;cr.z0=hz(cr.sc)+1.2;cr.d=proj(m[0],m[1],cr.z0+CH/2)[2]}
 cars.sort((x,y)=>y.d-x.d);
 for(const cr of cars){const u=cr.sc<R.sPortal-LC/2;const ca=Math.cos(cr.ang),sa=Math.sin(cr.ang);
  const L=(x,y,z)=>[cr.m[0]+x*ca-y*sa,cr.m[1]+x*sa+y*ca,cr.z0+z];const pr=pp=>proj(pp[0],pp[1],pp[2]);
  if(!u){g.fillStyle='rgba(0,0,0,.3)';g.beginPath();[[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([sx,sy],k)=>{const w=L(sx*LC/2,sy*CW/2,0),q=proj(w[0]+(hz(cr.sc)+CH)*.45,w[1]+(hz(cr.sc)+CH)*.8,0);k?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.fill()}
  else{g.save();g.shadowColor=CY;g.shadowBlur=60;g.fillStyle='rgba(111,230,255,.55)';g.beginPath();[[-1.5,-2.2],[1.5,-2.2],[1.5,2.2],[-1.5,2.2]].forEach(([sx,sy],k)=>{const w=L(sx*LC/2,sy*CW/2,-cr.z0),q=proj(w[0],w[1],0);k?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.fill();g.restore()}
  g.save();g.globalAlpha=u?.78:1;if(u){g.shadowColor=CY;g.shadowBlur=36}
  const faces=[{n:[0,1,0],c:[[-1,1,0],[1,1,0],[1,1,1],[-1,1,1]],col:[.93,.95,.97],side:1},{n:[0,-1,0],c:[[1,-1,0],[-1,-1,0],[-1,-1,1],[1,-1,1]],col:[.93,.95,.97],side:-1},{n:[1,0,0],c:[[1,1,0],[1,-1,0],[1,-1,1],[1,1,1]],col:cr.head?[.91,.25,.22]:[.8,.83,.86],front:1},{n:[-1,0,0],c:[[-1,-1,0],[-1,1,0],[-1,1,1],[-1,-1,1]],col:[.75,.78,.82]},{n:[0,0,1],c:[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],col:[.97,.98,1]}];
  for(const fc of faces){const nw=[fc.n[0]*ca-fc.n[1]*sa,fc.n[0]*sa+fc.n[1]*ca,fc.n[2]];
   const cen=L(fc.c.reduce((s,k)=>s+k[0],0)/4*LC/2,fc.c.reduce((s,k)=>s+k[1],0)/4*CW/2,fc.c.reduce((s,k)=>s+k[2],0)/4*CH);
   if(nw[0]*(eyeW[0]-cen[0])+nw[1]*(eyeW[1]-cen[1])+nw[2]*(eyeW[2]-cen[2])<=0)continue;
   const sh=.55+.45*Math.max(0,nw[0]*light[0]+nw[1]*light[1]+nw[2]*light[2]);const q=fc.c.map(k=>pr(L(k[0]*LC/2,k[1]*CW/2,k[2]*CH)));
   g.beginPath();q.forEach((p,k)=>k?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();
   let rgb=fc.col.map(v=>255*v*sh);if(u)rgb=rgb.map((v,k)=>v*.5+[111,230,255][k]*.5);g.fillStyle=`rgb(${rgb.map(Math.round).join(',')})`;g.fill();g.strokeStyle=u?'#b8f4ff':'rgba(0,0,0,.35)';g.lineWidth=u?3:1;g.stroke();
   const quad=(x0,x1,z0,z1,y,color)=>{const qq=[[x0,y,z0],[x1,y,z0],[x1,y,z1],[x0,y,z1]].map(k=>pr(L(k[0]*LC/2,k[1]*CW/2,k[2]*CH)));g.save();g.shadowBlur=0;g.beginPath();qq.forEach((p,k)=>k?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle=color;g.fill();g.restore()};
   if(fc.side){const y=fc.side;quad(-.92,.92,.28,.42,y,COL);for(let k=-3;k<=3;k++){if(!k)continue;quad(k*.26-.1,k*.26+.1,.55,.85,y,'rgba(25,45,75,.88)')}}
   if(fc.front&&cr.head){const qq=[[1,-.7,.45],[1,.7,.45],[1,.7,.85],[1,-.7,.85]].map(k=>pr(L(k[0]*LC/2,k[1]*CW/2,k[2]*CH)));g.save();g.shadowBlur=0;g.beginPath();qq.forEach((p,k)=>k?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle='#bfe6ff';g.fill();g.restore()}}
  g.restore()}
 // --- nhãn ga: kẹp trong lề 64 px, ẩn nếu rơi vào vùng tiêu đề/chú giải (y<250) hoặc sát đáy
 g.textBaseline='middle';
 for(const [name,q,u,kind] of labels){if(q[2]<60||q[0]<-100||q[0]>W+100||q[1]<-50||q[1]>H+50)continue;const port=kind==='portal';
  g.font=fnt(port?30:34);const ly=q[1]-(port?150:90),tw=g.measureText(name).width;if(ly-26<250||ly+26>H-110)continue;const cx=Math.max(64+tw/2+18,Math.min(W-64-tw/2-18,q[0]));
  g.save();if(port){g.shadowColor=CY;g.shadowBlur=24}
  g.strokeStyle=port?CY:'rgba(255,255,255,.7)';g.lineWidth=2;g.beginPath();g.moveTo(q[0],q[1]);g.lineTo(q[0],ly+26);g.stroke();
  g.fillStyle='rgba(10,18,40,.72)';g.strokeStyle=port?CY:'rgba(255,255,255,.5)';g.lineWidth=port?3:2;g.beginPath();g.roundRect(cx-tw/2-18,ly-26,tw+36,52,14);g.fill();g.stroke();g.restore();
  g.fillStyle=port?CY:'#fff';g.textAlign='center';g.fillText(name,cx,ly+1)}
 // --- tiêu đề + khung chú giải (chữ tự co để luôn nằm trong khung)
 g.textAlign='left';g.fillStyle='#ff4a4a';g.beginPath();g.arc(70,66,7,0,7);g.fill();g.fillStyle='#fff';g.font=fnt(26);g.fillText(HL,86,67);g.textAlign='right';g.fillText(HR,W-64,67);
 g.textAlign='left';g.fillStyle='rgba(10,18,40,.62)';g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=2;g.beginPath();g.roundRect(64,110,520,112,18);g.fill();g.stroke();
 g.fillStyle='#fff';{let fs=30;g.font=fnt(fs);while(g.measureText(TITLE).width>468&&fs>16){fs--;g.font=fnt(fs)}g.fillText(TITLE,84,142)}
 g.font=fnt(24);g.fillStyle=CY;g.save();g.strokeStyle=CY;g.shadowColor=CY;g.shadowBlur=10;g.lineWidth=9;g.beginPath();g.moveTo(84,182);g.lineTo(130,182);g.stroke();g.restore();g.fillText('Đi ngầm',142,190);
 g.fillStyle='#e3e7ec';g.fillRect(290,179,46,6);g.fillText('Trên cao',348,190);
 g.font=fnt(20);g.fillStyle='rgba(255,255,255,.75)';g.textAlign='center';g.fillText(CREDIT,W/2,H-40);
 return c}}
if(typeof module!=='undefined')module.exports={createDraw3D};
