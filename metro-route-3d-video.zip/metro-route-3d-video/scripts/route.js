// route.js — đọc KML -> tuyến mượt theo toạ độ Mercator (zoom Z) + hàm pt/tan/off theo chiều dài cung.
// Dùng được cả Node (module.exports) lẫn trình duyệt (window.MetroRoute).
(function(root){
function parseKML(text){
  const m=text.match(/<coordinates>([\s\S]*?)<\/coordinates>/);
  if(!m)throw new Error('KML không có <coordinates>');
  return m[1].trim().split(/\s+/).map(s=>s.split(',').map(Number).slice(0,2)); // [lon,lat]
}
function merc(lon,lat,Z){
  const WS=256*Math.pow(2,Z),s=Math.sin(lat*Math.PI/180);
  return [(lon+180)/360*WS,(0.5-Math.log((1+s)/(1-s))/(4*Math.PI))*WS];
}
// Catmull-Rom hướng tâm (centripetal), lấy mẫu dày
function catmull(P,per=40){
  const out=[],n=P.length,alpha=.5;
  const g=(i)=>P[Math.max(0,Math.min(n-1,i))];
  const t=(a,b)=>Math.pow(Math.hypot(b[0]-a[0],b[1]-a[1])||1e-6,alpha);
  for(let i=0;i<n-1;i++){
    const p0=g(i-1),p1=g(i),p2=g(i+1),p3=g(i+2);
    const t0=0,t1=t0+t(p0,p1),t2=t1+t(p1,p2),t3=t2+t(p2,p3);
    for(let k=0;k<per;k++){
      const tt=t1+(t2-t1)*k/per;
      const L=(a,b,ta,tb)=>[(tb-tt)/(tb-ta)*a[0]+(tt-ta)/(tb-ta)*b[0],(tb-tt)/(tb-ta)*a[1]+(tt-ta)/(tb-ta)*b[1]];
      const A1=L(p0,p1,t0,t1),A2=L(p1,p2,t1,t2),A3=L(p2,p3,t2,t3);
      const B1=[(t2-tt)/(t2-t0)*A1[0]+(tt-t0)/(t2-t0)*A2[0],(t2-tt)/(t2-t0)*A1[1]+(tt-t0)/(t2-t0)*A2[1]];
      const B2=[(t3-tt)/(t3-t1)*A2[0]+(tt-t1)/(t3-t1)*A3[0],(t3-tt)/(t3-t1)*A2[1]+(tt-t1)/(t3-t1)*A3[1]];
      out.push([(t2-tt)/(t2-t1)*B1[0]+(tt-t1)/(t2-t1)*B2[0],(t2-tt)/(t2-t1)*B1[1]+(tt-t1)/(t2-t1)*B2[1]]);
    }
  }
  out.push(P[n-1]);return out;
}
function resample(Q,STEP){
  const cum=[0];for(let i=1;i<Q.length;i++)cum.push(cum[i-1]+Math.hypot(Q[i][0]-Q[i-1][0],Q[i][1]-Q[i-1][1]));
  const L=cum[cum.length-1],X=[],Y=[];let j=0;
  for(let s=0;s<=L;s+=STEP){
    while(j<cum.length-2&&cum[j+1]<s)j++;
    const u=(s-cum[j])/((cum[j+1]-cum[j])||1);
    X.push(Q[j][0]+(Q[j+1][0]-Q[j][0])*u);Y.push(Q[j][1]+(Q[j+1][1]-Q[j][1])*u);
  }
  return {X,Y,L};
}
function smooth(A,w,passes){
  for(let p=0;p<passes;p++){
    const B=A.slice(),n=A.length;
    for(let i=0;i<n;i++){let s=0,c=0;for(let k=-w;k<=w;k++){const q=i+k;if(q<0||q>=n)continue;s+=A[q];c++}B[i]=s/c}
    B[0]=A[0];B[n-1]=A[n-1];A=B;
  }
  return A;
}
/**
 * lonlat: [[lon,lat],...]  (từ parseKML)
 * opts: {reverse, Z=16, STEP=2, win=22, passes=3}
 * stations: [[tên,lat,lon],...] theo thứ tự đi từ đầu tuyến; portalBetween: [chỉ số ga ngầm cuối, tỉ lệ 0..1 tới ga kế]
 */
function buildRoute(lonlat,stations,opts={}){
  const {reverse=false,Z=16,STEP=2,win=22,passes=3,portalBetween=[2,.3],tileUrl='/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'}=opts;
  let pts=lonlat.map(([lo,la])=>merc(lo,la,Z));if(reverse)pts.reverse();
  const rs=resample(catmull(pts),STEP);
  const X=smooth(rs.X,win,passes),Y=smooth(rs.Y,win,passes);
  const R={X,Y,STEP,Z,len:(X.length-1)*STEP,ST:stations,cache:new Map()};
  R.pt=s=>{s=Math.max(0,Math.min(s,(X.length-1)*STEP));const f=s/STEP,i=Math.min(Math.floor(f),X.length-2),u=f-i;return[X[i]+(X[i+1]-X[i])*u,Y[i]+(Y[i+1]-Y[i])*u]};
  R.tan=s=>{const a=R.pt(s-6),b=R.pt(s+6),dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[dx/l,dy/l]};
  R.off=(s,o)=>{const p=R.pt(s),t=R.tan(s);return[p[0]-t[1]*o,p[1]+t[0]*o]};
  // gán ga vào điểm gần nhất trên tuyến
  R.stS=stations.map(([n,la,lo])=>{const m=merc(lo,la,Z);let best=0,bd=1e18;for(let i=0;i<X.length;i++){const d=(X[i]-m[0])**2+(Y[i]-m[1])**2;if(d<bd){bd=d;best=i}}return best*STEP});
  R.stS[0]=Math.max(R.stS[0],32);R.stS[R.stS.length-1]=Math.min(R.stS[R.stS.length-1],R.len-26); // lùi ga đầu/cuối vào trong để tàu nằm trọn trên ga
  const [ia,fr]=portalBetween;R.sPortal=R.stS[ia]+fr*(R.stS[ia+1]-R.stS[ia]);
  // tải tile (chỉ trình duyệt)
  R.tile=async(x,y)=>{const k=x+'/'+y;if(R.cache.has(k))return R.cache.get(k);
    const u=tileUrl.replace('{z}',Z).replace('{y}',y).replace('{x}',x);
    const pr=fetch(u).then(r=>r.blob()).then(b=>createImageBitmap(b)).catch(()=>null);R.cache.set(k,pr);return pr};
  return R;
}
const api={parseKML,merc,buildRoute};
if(typeof module!=='undefined')module.exports=api;else root.MetroRoute=api;
})(typeof window!=='undefined'?window:globalThis);
