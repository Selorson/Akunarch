// exporter.js — dán vào javascript_tool của khung trình duyệt (app Claude desktop), SAU KHI đã có:
//   window.RT   = MetroRoute.buildRoute(...)      (route.js)
//   window.draw3D = createDraw3D(RT,{font:'...'}) (metro3d.js)
// Chạy bất đồng bộ; hỏi window.ST {i,n,done,err,vis,size,dur,secs}. Xong có nút tải + video kiểm tra.
// Khung trình duyệt PHẢI ở trạng thái 'visible' trong lúc xuất. JS timeout ~45 s -> dùng polling.
window.ST={i:0,n:900,done:false,err:null,vis:document.visibilityState};
(async()=>{try{
const N=900,FPS=30,Wd=1080,Ht=1920,L=RT.len,Tt=N/FPS,NAME='metro_30s.webm';
const ss=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};const lerp=(a,b,k)=>a+(b-a)*k;
// ---- Dòng thời gian mẫu: tàu A ga đầu -> ga cuối, tàu B ngược lại; tăng/giảm tốc 2.5 s ----
const a0=RT.stS[0]+165,a1=RT.stS[RT.stS.length-1],b0=L-170,b1=RT.stS[0]+10,ra=2.5;
const prof=t=>{const v=1/(Tt-ra);return t<ra?v*t*t/(2*ra):t<Tt-ra?v*ra/2+v*(t-ra):1-v*(Tt-t)*(Tt-t)/(2*ra)};
const frame=t=>{const p=prof(t);const sA=lerp(a0,a1,p),pB=lerp(b0,b1,p);
 let yaw=lerp(-38,34,ss((t-9)/4));yaw=lerp(yaw,-30,ss((t-19)/4));const pb=ss((t-26)/4); // 26-30 s kéo lùi toàn cảnh
 return [sA,pB,{yaw:lerp(yaw,-12,pb),alpha:lerp(32,40,pb),D:lerp(270,430,pb),ahead:lerp(-70,130,pb)}]};
// ---- Mã hoá VP8 bằng WebCodecs ----
const chunks=[];const enc=new VideoEncoder({output:(c)=>{const b=new Uint8Array(c.byteLength);c.copyTo(b);chunks.push({b,t:c.timestamp,k:c.type==='key'})},error:e=>{ST.err=String(e)}});
enc.configure({codec:'vp8',width:Wd,height:Ht,bitrate:8e6,framerate:FPS});
const t0=performance.now();
for(let i=0;i<N;i++){const [sA,pB,o]=frame(i/FPS);const c=await draw3D(sA,pB,o);
 const f=new VideoFrame(c,{timestamp:Math.round(i*1e6/FPS)});enc.encode(f,{keyFrame:i%60===0});f.close();
 while(enc.encodeQueueSize>6)await new Promise(r=>setTimeout(r,5));ST.i=i+1;ST.vis=document.visibilityState;ST.secs=((performance.now()-t0)/1000)|0}
await enc.flush();
// ---- Ghép WebM (EBML) ----
const cat=a=>{let n=0;a.forEach(x=>n+=x.length);const o=new Uint8Array(n);let p=0;a.forEach(x=>{o.set(x,p);p+=x.length});return o};
const idb=id=>{const b=[];let x=id;while(x>0){b.unshift(x&255);x=Math.floor(x/256)}return new Uint8Array(b)};
const szb=n=>{const b=new Uint8Array(8);b[0]=1;for(let i=7;i>=1;i--){b[i]=n&255;n=Math.floor(n/256)}return b};
const el=(id,d)=>cat([idb(id),szb(d.length),d]);
const uint=n=>{const b=[];let x=n;do{b.unshift(x&255);x=Math.floor(x/256)}while(x>0);return new Uint8Array(b)};
const flt=x=>{const b=new Uint8Array(8);new DataView(b.buffer).setFloat64(0,x);return b};
const str=s=>new TextEncoder().encode(s);
const hdr=el(0x1A45DFA3,cat([el(0x4286,uint(1)),el(0x42F7,uint(1)),el(0x42F2,uint(4)),el(0x42F3,uint(8)),el(0x4282,str('webm')),el(0x4287,uint(2)),el(0x4285,uint(2))]));
const info=el(0x1549A966,cat([el(0x2AD7B1,uint(1000000)),el(0x4489,flt(Tt*1000)),el(0x4D80,str('x')),el(0x5741,str('x'))]));
const tr=el(0x1654AE6B,el(0xAE,cat([el(0xD7,uint(1)),el(0x73C5,uint(1)),el(0x83,uint(1)),el(0x86,str('V_VP8')),el(0xE0,cat([el(0xB0,uint(Wd)),el(0xBA,uint(Ht))]))])));
const cl=[];let cur=null;
for(const c of chunks){const ms=Math.round(c.t/1000);if(c.k||!cur){cur={ms,blocks:[]};cl.push(cur)}const rel=ms-cur.ms;cur.blocks.push(el(0xA3,cat([new Uint8Array([0x81,(rel>>8)&255,rel&255,c.k?0x80:0]),c.b])))}
const cls=cl.map(x=>el(0x1F43B675,cat([el(0xE7,uint(x.ms)),...x.blocks])));
const seg=cat([idb(0x18538067),new Uint8Array([1,255,255,255,255,255,255,255]),info,tr,...cls]);
const blob=new Blob([hdr,seg],{type:'video/webm'});const url=URL.createObjectURL(blob);
document.body.innerHTML='';document.body.style.cssText='background:#111;color:#fff;font:16px sans-serif;padding:12px';
const a=document.createElement('a');a.id='vl';a.href=url;a.download=NAME;a.textContent='⬇ TẢI VIDEO '+NAME;a.style.cssText='display:block;padding:14px;background:#e8403a;color:#fff;font-size:20px;text-decoration:none;margin-bottom:10px';document.body.appendChild(a);
const vd=document.createElement('video');vd.src=url;vd.controls=true;vd.muted=true;vd.style.width='360px';document.body.appendChild(vd);
vd.onloadedmetadata=()=>{ST.dur=vd.duration};ST.size=blob.size;ST.done=true;
}catch(e){ST.err=String(e&&e.stack||e)}})();
