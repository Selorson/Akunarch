metro-route-3d-video — skill dựng video tuyến metro 3D (9:16) trên ảnh vệ tinh Esri.

Cách dùng trên máy khác:
1) Giải nén thư mục metro-route-3d-video vào thư mục skills của Claude (hoặc tải lên Settings > Skills dạng .zip).
2) Hỏi Claude: "dùng skill metro-route-3d-video, tuyến này..." kèm file KML + danh sách ga.
Tệp: SKILL.md (quy tắc + quy trình), scripts/route.js (KML -> tuyến mượt), scripts/metro3d.js (vẽ 1 khung 3D),
scripts/exporter.js (xuất WebM 30 s), scripts/stations_example.json (mẫu ga Bến Thành–Suối Tiên).
Yêu cầu: app Claude desktop có khung trình duyệt (render canvas + WebCodecs).
